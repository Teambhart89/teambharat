<?php
/**
 * About page template (slug: about). Content is editable in Pages.
 *
 * @package Avdesh_SEO
 */
get_header();
$name = avseo_info( 'name' );
while ( have_posts() ) :
	the_post();
	?>

	<section class="page-hero">
		<div class="container">
			<?php avseo_breadcrumbs(); ?>
			<span class="eyebrow">About</span>
			<h1><?php the_title(); ?></h1>
			<?php if ( has_excerpt() ) : ?>
				<p class="lead"><?php echo esc_html( get_the_excerpt() ); ?></p>
			<?php endif; ?>
		</div>
	</section>

	<section class="bg-cream">
		<div class="container">
			<div class="about-grid">
				<div class="prose entry-content">
					<?php the_content(); ?>
				</div>
				<div>
					<?php avseo_image_slot( 'img_about', 'Add your about photo', $name, 'about-photo', '700 x 800 px' ); ?>
				</div>
			</div>
		</div>
	</section>

	<?php
endwhile;
avseo_cta_band();
get_footer();
